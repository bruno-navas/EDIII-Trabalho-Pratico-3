
#ifndef FUNCIONALIDADES_H
#define FUNCIONALIDADES_H


//funcionalidades em ordem
void Cria_grafo_e_exibe();

void Exibe_predadores();

void Identifica_ciclos();

void Analisa_conexoes();

void Relacao_presa_predador();

#endif //FUNCIONALIDADES_H
